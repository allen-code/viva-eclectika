function dateDiff( str1, str2 ) {
    var diff = Date.parse( str2 ) - Date.parse( str1 ); 
    return isNaN( diff ) ? NaN : {
    	diff : diff,
    	ms : Math.floor( diff            % 1000 ),
    	s  : Math.floor( diff /     1000 %   60 ),
    	m  : Math.floor( diff /    60000 %   60 ),
    	h  : Math.floor( diff /  3600000 %   24 ),
    	d  : Math.floor( diff / 86400000        )
    };
}

function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    setInterval(function () {
        var danceday = new Date(2016, 3, 2, 19, 0, 0, 0);
        var date = Date();

        display.textContent = dateDiff(date, danceday).d +" days "+ 
                              dateDiff(date, danceday).h+" hours";
        display.style = 'color: #ffff00; font-size: 20px; cursor: pointer;  border:none;';

        if (--timer < 0) {
            timer = duration;
        }
    }, 1000);
}

window.onload = function () {
    var fiveMinutes = 60 * 5,
        display = document.getElementById("menu-item-542");
    startTimer(fiveMinutes, display);
};